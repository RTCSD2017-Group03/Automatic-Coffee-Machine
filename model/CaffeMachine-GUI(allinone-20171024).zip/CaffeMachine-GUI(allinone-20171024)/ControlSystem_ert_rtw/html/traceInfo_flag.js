function TraceInfoFlag() {
    this.traceFlag = new Array();
    this.traceFlag["ControlSystem.c:565c48"]=1;
    this.traceFlag["ControlSystem.c:566c55"]=1;
    this.traceFlag["ControlSystem.c:567c16"]=1;
    this.traceFlag["ControlSystem.c:684c31"]=1;
    this.traceFlag["ControlSystem.c:684c36"]=1;
    this.traceFlag["ControlSystem.c:684c62"]=1;
    this.traceFlag["ControlSystem.c:685c29"]=1;
    this.traceFlag["ControlSystem.c:688c26"]=1;
    this.traceFlag["ControlSystem.c:712c38"]=1;
}
top.TraceInfoFlag.instance = new TraceInfoFlag();
